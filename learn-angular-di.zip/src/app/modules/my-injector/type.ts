
export const Type = Function;

export function isType(v: any): v is Type<any> {
  return typeof v === 'function';
}

export interface Type<T> extends Function {
   new (...args: any[]): T;
}

/**
 * @description
 *
 * Represents an abstract class `T`, if applied to a concrete class it would stop being
 * instantiatable.
 *
 * @publicApi
 */
export interface AbstractType<T> extends Function {
  prototype: T;
}

export enum InjectFlags {

  Default = 0b0000,

  Self = 0b0001,

  SkipSelf = 0b0010,

  Optional = 0b0100,
}


const IDENT = function<T>(value: T): T {
  return value;
};

const EMPTY = [] as any[];

const CIRCULAR = IDENT;

const MULTI_PROVIDER_FN = function(): any[] {
  return Array.prototype.slice.call(arguments);
};

const enum OptionFlags {
  
  // 0001
  Optional = 0b01,
  
  // 0010
  CheckSelf = 1 << 1,
  
  // 0010
  CheckParent = 1 << 2,
  Default = CheckSelf | CheckParent
}

const NO_NEW_LINE = 'ɵ';
